package cmsc433.p4.enums;

public enum AccessType {
	CONCURRENT_READ,
	EXCLUSIVE_WRITE
}
